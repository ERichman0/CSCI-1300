#include <iostream> 

using namespace std;

int main(){
    string userName;//initialize variabel to hold user input
    cout<<"Enter your name:"<<endl;//ask user to enter name 
    cin>>userName;//set userName to the user input 
    cout<<"Hello,"<<userName<<"!"<<endl; //print line 
    return 0;
}