/* There will be three main functions in our project 

1)Store Function 
The store function serves as a way to implement the store at the begining of the game and use forts throughout the game 
The main function in this will present a menu to the player using a while statement and use a switch 
statement to determine what the player wants to buy 
There will be a integer variable that holds the amount they have spent and how much cash they have left 

2)Turn Function
The turn function will consist of 4 smaller functions and a main function
1 for each possible action and then a status update function that will run at the begining of the turn 
The player will be presented a menu of what their possible actions are and using a switch statment will determine which smaller functions to call

3)Misfortune function
The misfortune function will consist of 5 smaller functions 
the first determining if a misfortune will actually happen 
then if a misfortune happens there will be a function to determine if the raiders will attack 
then there will be other functions for each possible misfortune 
*/ 